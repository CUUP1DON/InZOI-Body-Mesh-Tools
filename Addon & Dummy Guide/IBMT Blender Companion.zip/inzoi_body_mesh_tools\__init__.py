bl_info = {
    "name":        "InZOI Body Mesh Tools Companion",
    "author":      "CUUPIDON",
    "version":     (0, 0, 4),
    "blender":     (4, 5, 0),
    "location":    "3D Viewport > Sidebar (N) > Body Mesh Tools",
    "description": "Export shape key deltas as JSON for the Body Mesh Tools UE plugin",
    "category":    "Mesh",
}

import bpy
import bmesh
import json
import math
import os
import mathutils
from bpy.props import StringProperty, PointerProperty, EnumProperty, FloatProperty, IntProperty
from bpy.types import PropertyGroup, Operator, Panel
from . import messages as M

_EPSILON = 1e-6
_BOUNDARY_VGROUP = "InZOI_MorphBoundary"
_STATUS_CLEAR_DELAY = 6.0  # seconds before status messages auto-clear


def _schedule_clear():
    """Register a one-shot timer that clears both status fields."""
    def _clear():
        props = bpy.context.scene.inzoi_morph_props
        props.status = ""
        props.boundary_status = ""
        return None  # returning None cancels the timer
    bpy.app.timers.register(_clear, first_interval=_STATUS_CLEAR_DELAY)


def _compute_deltas(obj, sk_name):
    """Return a list of mathutils.Vector deltas (local space), one per basis vertex."""
    mesh      = obj.data
    basis     = mesh.shape_keys.reference_key
    target    = mesh.shape_keys.key_blocks.get(sk_name)
    if not target:
        return None
    basis_co  = basis.data
    target_co = target.data
    return [
        mathutils.Vector(target_co[i].co) - mathutils.Vector(basis_co[i].co)
        for i in range(len(basis_co))
    ]


def _build_adjacency(mesh):
    """Return {vertex_index: [neighbour_indices]} built from mesh edges."""
    adj = {i: [] for i in range(len(mesh.vertices))}
    for edge in mesh.edges:
        a, b = edge.vertices[0], edge.vertices[1]
        adj[a].append(b)
        adj[b].append(a)
    return adj


def _detect_boundary_verts(mesh, deltas, threshold, ratio):
    """
    Walk every mesh edge.  Flag both endpoints of an edge as a boundary
    whenever one side has delta magnitude > threshold and the other side's
    magnitude is less than (ratio * large side).  This catches the 'cliff'
    where a shape key's influence ends sharply.
    Returns a set of vertex indices.
    """
    flagged = set()
    for edge in mesh.edges:
        a, b  = edge.vertices[0], edge.vertices[1]
        mag_a = deltas[a].length
        mag_b = deltas[b].length
        large = max(mag_a, mag_b)
        small = min(mag_a, mag_b)
        if large > threshold and small < large * ratio:
            flagged.add(a)
            flagged.add(b)
    return flagged


def _laplacian_smooth_shape_key(obj, sk_name, seed_verts, passes):
    """
    Expand from seed_verts by (passes-1) extra edge rings to create a
    transition zone, then run 'passes' Laplacian iterations over that zone,
    modifying the shape key coordinates in-place.
    Returns the number of vertices that were smoothed.
    """
    mesh   = obj.data
    sk     = mesh.shape_keys
    basis  = sk.reference_key
    target = sk.key_blocks.get(sk_name)
    if not target:
        return 0

    adj = _build_adjacency(mesh)

    # Expand zone
    zone = set(seed_verts)
    for _ in range(max(0, passes - 1)):
        zone.update(nb for vi in list(zone) for nb in adj[vi] if nb not in zone)

    basis_co  = basis.data
    target_co = target.data

    for _ in range(passes):
        # Snapshot deltas for zone + their immediate neighbours (read-only)
        needed = set(zone)
        for vi in zone:
            needed.update(adj[vi])
        snapshot = {
            vi: mathutils.Vector(target_co[vi].co) - mathutils.Vector(basis_co[vi].co)
            for vi in needed
        }
        # Laplacian average and write back
        for vi in zone:
            nbrs = [nb for nb in adj[vi] if nb in snapshot]
            if not nbrs:
                continue
            avg = snapshot[vi].copy()
            for nb in nbrs:
                avg += snapshot[nb]
            avg /= (1.0 + len(nbrs))
            bp = mathutils.Vector(basis_co[vi].co)
            target_co[vi].co = (bp.x + avg.x, bp.y + avg.y, bp.z + avg.z)

    return len(zone)


def _shape_key_items(self, context):
    obj = self.source_object
    if obj and obj.type == 'MESH' and obj.data.shape_keys:
        ref = obj.data.shape_keys.reference_key
        items = [
            (kb.name, kb.name, "")
            for kb in obj.data.shape_keys.key_blocks
            if kb != ref
        ]
        if items:
            return items
    return [("__NONE__", "(no shape keys)", "")]


_THRESHOLD_DEFAULT = 0.002
_RATIO_DEFAULT     = 0.25


class InZOIMorphProps(PropertyGroup):
    source_object: PointerProperty(
        name=M.PROP_SOURCE_OBJECT_NAME,
        description=M.PROP_SOURCE_OBJECT_DESC,
        type=bpy.types.Object,
        poll=lambda self, o: o.type == 'MESH',
    )
    shape_key_name: EnumProperty(
        name=M.PROP_SHAPE_KEY_NAME,
        description=M.PROP_SHAPE_KEY_DESC,
        items=_shape_key_items,
    )
    morph_ue_name: StringProperty(
        name=M.PROP_MORPH_UE_NAME,
        description=M.PROP_MORPH_UE_DESC,
        default="Body_Muscle",
    )
    output_path: StringProperty(
        name=M.PROP_OUTPUT_PATH_NAME,
        description=M.PROP_OUTPUT_PATH_DESC,
        default="//",
        subtype='DIR_PATH',
    )
    status: StringProperty(default="")
    smooth_threshold: FloatProperty(
        name=M.PROP_THRESHOLD_NAME,
        description=M.PROP_THRESHOLD_DESC,
        default=_THRESHOLD_DEFAULT, min=0.0, max=1.0, precision=4, step=1, subtype='FACTOR',
    )
    smooth_ratio: FloatProperty(
        name=M.PROP_RATIO_NAME,
        description=M.PROP_RATIO_DESC,
        default=_RATIO_DEFAULT, min=0.0, max=1.0, precision=2, subtype='FACTOR',
    )
    smooth_passes: IntProperty(
        name=M.PROP_PASSES_NAME,
        description=M.PROP_PASSES_DESC,
        default=2, min=1, max=10,
    )
    boundary_status: StringProperty(default="")


class INZOI_OT_ExportMorphJson(Operator):
    bl_idname  = "inzoi.export_morph_json"
    bl_label   = M.OP_EXPORT_LABEL
    bl_options = {'REGISTER'}

    def execute(self, context):
        props   = context.scene.inzoi_morph_props
        props.status = ""
        obj     = props.source_object
        sk_name = props.shape_key_name
        out_dir = bpy.path.abspath(props.output_path)
        ue_name = props.morph_ue_name.strip() or sk_name
        safe_name = "".join(c if c.isalnum() or c in "_-" else "_" for c in ue_name)
        output  = os.path.join(out_dir, safe_name + ".json")

        if not obj:
            return self._fail(props, M.ERR_NO_OBJECT)
        if obj.type != 'MESH':
            return self._fail(props, M.ERR_NOT_MESH)
        if not obj.data.shape_keys:
            return self._fail(props, M.ERR_NO_SHAPE_KEYS)
        if sk_name in ("__NONE__", ""):
            return self._fail(props, M.ERR_NO_KEY_SELECTED)
        if not out_dir:
            return self._fail(props, M.ERR_NO_OUTPUT_DIR)
        if not os.path.isdir(out_dir):
            return self._fail(props, M.ERR_OUTPUT_NOT_EXIST.format(path=out_dir))

        mesh       = obj.data
        basis_key  = mesh.shape_keys.reference_key
        target_key = mesh.shape_keys.key_blocks.get(sk_name)
        if not target_key:
            return self._fail(props, M.ERR_KEY_NOT_FOUND.format(name=sk_name))

        # ── Ensure Object Mode and morph at 1.0 before export ────────────────
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        context.view_layer.objects.active = obj
        obj.select_set(True)
        target_key.value = 1.0
        context.view_layer.update()

        saved         = {kb.name: kb.value for kb in mesh.shape_keys.key_blocks}
        saved[sk_name] = 0.0  # restore morph to 0 (rest shape) after export
        world_mat     = obj.matrix_world
        world_mat_3x3 = world_mat.to_3x3()
        normal_mat    = world_mat_3x3.inverted().transposed()

        # Auto-detect unit scale: FModel exports at scale 1.0 store raw UE cm as
        # Blender units, making a body ~175 units tall. A correctly-scaled import
        # (scale 0.01) produces ~1.75 units. Threshold of 10 safely separates them.
        bbox_corners = [world_mat @ mathutils.Vector(c) for c in obj.bound_box]
        bbox_height  = max(c.z for c in bbox_corners) - min(c.z for c in bbox_corners)
        unit_scale   = 0.01 if bbox_height > 10.0 else 1.0

        try:
            for kb in mesh.shape_keys.key_blocks:
                kb.value = 0.0
            context.view_layer.update()
            dep     = context.evaluated_depsgraph_get()
            ev      = obj.evaluated_get(dep)
            em      = ev.to_mesh()
            bn_list = [v.normal.copy() for v in em.vertices]
            ev.to_mesh_clear()

            target_key.value = 1.0
            context.view_layer.update()
            dep     = context.evaluated_depsgraph_get()
            ev      = obj.evaluated_get(dep)
            em      = ev.to_mesh()
            dn_list = [v.normal.copy() for v in em.vertices]
            ev.to_mesh_clear()
        finally:
            for kb in mesh.shape_keys.key_blocks:
                if kb.name in saved:
                    kb.value = saved[kb.name]
            context.view_layer.update()
            for area in context.screen.areas:
                area.tag_redraw()

        basis_co  = basis_key.data
        target_co = target_key.data
        verts_out = []

        for i in range(len(basis_co)):
            bp = basis_co[i].co
            tp = target_co[i].co
            dx = tp.x - bp.x
            dy = tp.y - bp.y
            dz = tp.z - bp.z
            if math.sqrt(dx*dx + dy*dy + dz*dz) <= _EPSILON:
                continue

            bp_w = (world_mat @ bp) * unit_scale
            d_w  = (world_mat_3x3 @ mathutils.Vector((dx, dy, dz))) * unit_scale
            bn_w = (normal_mat @ bn_list[i]).normalized()
            dn_w = (normal_mat @ dn_list[i]).normalized()

            verts_out.append({
                "blenderIdx":     i,
                "basisPos":       [bp_w.x,  bp_w.y,  bp_w.z],
                "delta":          [d_w.x,   d_w.y,   d_w.z],
                "basisNormal":    [bn_w.x,  bn_w.y,  bn_w.z],
                "deformedNormal": [dn_w.x,  dn_w.y,  dn_w.z],
            })

        data = {
            "morphName":          ue_name,
            "blenderObject":      obj.name,
            "basisVertexCount":   len(basis_co),
            "exportedDeltaCount": len(verts_out),
            "vertices":           verts_out,
        }

        try:
            with open(output, "w", encoding="utf-8") as f:
                json.dump(data, f, separators=(",", ":"))
        except OSError as e:
            return self._fail(props, M.ERR_FILE_WRITE.format(error=e))

        msg = M.OK_EXPORT.format(count=len(verts_out), path=output)
        props.status = msg
        self.report({'INFO'}, msg.replace("\n", " "))
        _schedule_clear()
        return {'FINISHED'}

    def _fail(self, props, msg):
        props.status = "ERROR: " + msg
        self.report({'ERROR'}, msg)
        _schedule_clear()
        return {'CANCELLED'}


class INZOI_OT_AnalyzeBoundaries(Operator):
    bl_idname  = "inzoi.analyze_boundaries"
    bl_label   = M.OP_ANALYZE_LABEL
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props   = context.scene.inzoi_morph_props
        props.boundary_status = ""
        obj     = props.source_object
        sk_name = props.shape_key_name

        if not obj or obj.type != 'MESH':
            return self._fail(props, M.ERR_SELECT_MESH)
        if not obj.data.shape_keys:
            return self._fail(props, M.ERR_NO_SHAPE_KEYS)
        if sk_name in ("__NONE__", ""):
            return self._fail(props, M.ERR_SELECT_SHAPE_KEY)

        deltas = _compute_deltas(obj, sk_name)
        if deltas is None:
            return self._fail(props, M.ERR_KEY_NOT_FOUND.format(name=sk_name))

        # Set the morph to full strength so the user can see the shape they are
        # smoothing while inspecting the boundary vertices in the viewport.
        target_key = obj.data.shape_keys.key_blocks.get(sk_name)
        if target_key:
            target_key.value = 1.0

        flagged = _detect_boundary_verts(
            obj.data, deltas,
            props.smooth_threshold,
            props.smooth_ratio,
        )

        flagged_set = flagged  # already a set

        # ── Vertex group update requires Object Mode ──────────────────────────
        # Always go to Object Mode first (works regardless of starting mode),
        # update the vertex group, then re-enter Edit Mode for selection.
        was_edit = (context.mode == 'EDIT_MESH')
        if was_edit:
            bpy.ops.object.mode_set(mode='OBJECT')

        context.view_layer.objects.active = obj
        obj.select_set(True)

        vg = obj.vertex_groups.get(_BOUNDARY_VGROUP)
        if vg:
            obj.vertex_groups.remove(vg)
        vg = obj.vertex_groups.new(name=_BOUNDARY_VGROUP)
        if flagged:
            vg.add(list(flagged_set), 1.0, 'REPLACE')

        # ── Back to Edit Mode for bmesh vertex selection ──────────────────────
        bpy.ops.object.mode_set(mode='EDIT')

        context.tool_settings.mesh_select_mode = (True, False, False)
        bm = bmesh.from_edit_mesh(obj.data)
        bm.verts.ensure_lookup_table()
        for v in bm.verts:
            v.select = (v.index in flagged_set)
        bm.select_flush_mode()
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)

        msg = M.OK_ANALYZE.format(count=len(flagged), group=_BOUNDARY_VGROUP)
        props.boundary_status = msg
        self.report({'INFO'}, msg)
        _schedule_clear()
        return {'FINISHED'}

    def _fail(self, props, msg):
        props.boundary_status = "ERROR: " + msg
        self.report({'ERROR'}, msg)
        _schedule_clear()
        return {'CANCELLED'}


class INZOI_OT_ResetSmoothDefaults(Operator):
    bl_idname  = "inzoi.reset_smooth_defaults"
    bl_label   = M.OP_RESET_LABEL
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Reset Min Delta and Drop Ratio to their default values"

    def execute(self, context):
        props = context.scene.inzoi_morph_props
        props.smooth_threshold = _THRESHOLD_DEFAULT
        props.smooth_ratio     = _RATIO_DEFAULT
        props.boundary_status  = ""
        return {'FINISHED'}


class INZOI_OT_SmoothBoundaries(Operator):
    bl_idname  = "inzoi.smooth_boundaries"
    bl_label   = M.OP_SMOOTH_LABEL
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props   = context.scene.inzoi_morph_props
        props.boundary_status = ""
        obj     = props.source_object
        sk_name = props.shape_key_name

        if not obj or obj.type != 'MESH':
            return self._fail(props, M.ERR_SELECT_MESH)
        if not obj.data.shape_keys:
            return self._fail(props, M.ERR_NO_SHAPE_KEYS)
        if sk_name in ("__NONE__", ""):
            return self._fail(props, M.ERR_SELECT_SHAPE_KEY)

        deltas = _compute_deltas(obj, sk_name)
        if deltas is None:
            return self._fail(props, M.ERR_KEY_NOT_FOUND.format(name=sk_name))

        flagged = _detect_boundary_verts(
            obj.data, deltas,
            props.smooth_threshold,
            props.smooth_ratio,
        )

        if not flagged:
            props.boundary_status = M.WARN_NOTHING_TO_SMOOTH
            self.report({'WARNING'}, M.WARN_NOTHING_TO_SMOOTH)
            _schedule_clear()
            return {'FINISHED'}

        affected = _laplacian_smooth_shape_key(
            obj, sk_name, flagged, props.smooth_passes)

        obj.data.update_tag()
        for area in context.screen.areas:
            area.tag_redraw()

        msg = M.OK_SMOOTH.format(
            passes=props.smooth_passes, seeds=len(flagged), total=affected)
        props.boundary_status = msg
        self.report({'INFO'}, msg)
        _schedule_clear()
        return {'FINISHED'}

    def _fail(self, props, msg):
        props.boundary_status = "ERROR: " + msg
        self.report({'ERROR'}, msg)
        _schedule_clear()
        return {'CANCELLED'}


class INZOI_PT_MorphPanel(Panel):
    bl_label       = "Body Muscle Delta Exporter"
    bl_idname      = "INZOI_PT_MorphPanel"
    bl_space_type  = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category    = "Body Mesh Tools"

    def draw(self, context):
        layout = self.layout
        props  = context.scene.inzoi_morph_props

        col = layout.column(align=True)
        col.prop(props, "source_object")
        col.prop(props, "shape_key_name")

        layout.separator()

        # ── Boundary Smoother ──────────────────────────────────────────────
        box = layout.box()
        box.label(text=M.PANEL_SECTION_SMOOTHER, icon='MOD_SMOOTH')

        row = box.row(align=True)
        row.prop(props, "smooth_threshold")
        row.prop(props, "smooth_ratio")
        row.operator("inzoi.reset_smooth_defaults", text="", icon='LOOP_BACK')

        row2 = box.row(align=True)
        row2.operator("inzoi.analyze_boundaries", icon='VIEWZOOM')
        row2.prop(props, "smooth_passes")
        box.operator("inzoi.smooth_boundaries", icon='AUTOMERGE_ON')

        if props.boundary_status:
            sub = box.column(align=True)
            sub.alert = props.boundary_status.startswith("ERROR")
            for line in props.boundary_status.split("\n"):
                sub.label(text=line)

        layout.separator(factor=0.5)

        # ── Exporter ───────────────────────────────────────────────────────
        layout.prop(props, "morph_ue_name")
        layout.prop(props, "output_path")

        layout.separator()
        layout.operator("inzoi.export_morph_json", icon='EXPORT')

        if props.status:
            box2 = layout.box()
            col2 = box2.column(align=True)
            col2.alert = props.status.startswith("ERROR")
            for line in props.status.split("\n"):
                col2.label(text=line)


_classes = (
    InZOIMorphProps,
    INZOI_OT_ResetSmoothDefaults,
    INZOI_OT_AnalyzeBoundaries,
    INZOI_OT_SmoothBoundaries,
    INZOI_OT_ExportMorphJson,
    INZOI_PT_MorphPanel,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.inzoi_morph_props = PointerProperty(type=InZOIMorphProps)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.inzoi_morph_props


if __name__ == "__main__":
    register()