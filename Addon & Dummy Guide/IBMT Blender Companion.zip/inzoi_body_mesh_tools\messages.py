# messages.py — all user-facing strings for InZOI Body Mesh Tools Companion
# Edit this file to customise labels, hints, and error/status messages.

# ── Property labels & descriptions ────────────────────────────────────────────

PROP_SOURCE_OBJECT_NAME  = "Object"
PROP_SOURCE_OBJECT_DESC  = "Mesh object that has the shape key to export"

PROP_SHAPE_KEY_NAME      = "Shape Key"
PROP_SHAPE_KEY_DESC      = "Shape key to export"

PROP_MORPH_UE_NAME       = "UE Morph Name"
PROP_MORPH_UE_DESC       = (
    "Name written into the JSON — must match the morph name in inZOI"
)

PROP_OUTPUT_PATH_NAME    = "Output Folder"
PROP_OUTPUT_PATH_DESC    = (
    "Directory where the exported .json file will be saved "
    "(filename is generated from UE Morph Name)"
)

PROP_THRESHOLD_NAME      = "Min Delta"
PROP_THRESHOLD_DESC      = (
    "Minimum delta length (Blender units) for a vertex to be considered "
    "'moving'. Vertices below this are treated as zero for boundary detection."
)

PROP_RATIO_NAME          = "Drop Ratio"
PROP_RATIO_DESC          = (
    "An edge is flagged as a boundary when the smaller side's delta is less "
    "than this fraction of the larger side. "
    "Lower values catch only steeper drop-offs."
)

PROP_PASSES_NAME         = "Passes"
PROP_PASSES_DESC         = (
    "Laplacian smoothing passes. Each pass also widens the transition zone "
    "by one edge ring."
)

# ── Operator labels ────────────────────────────────────────────────────────────

OP_EXPORT_LABEL          = "Export Morph JSON"
OP_ANALYZE_LABEL         = "Analyze Boundaries"
OP_SMOOTH_LABEL          = "Smooth Boundaries"
OP_RESET_LABEL           = "Reset Defaults"

# ── Panel / section labels ─────────────────────────────────────────────────────

PANEL_SECTION_SMOOTHER   = "Boundary Smoother"
PANEL_SECTION_EXPORTER   = "Morph Exporter"

# ── Export operator messages ───────────────────────────────────────────────────

ERR_NO_OBJECT            = "No object selected."
ERR_NOT_MESH             = "Object is not a mesh."
ERR_NO_SHAPE_KEYS        = "Object has no shape keys."
ERR_NO_KEY_SELECTED      = "No shape key selected."
ERR_NO_OUTPUT_DIR        = "No output directory set."
ERR_OUTPUT_NOT_EXIST     = "Output directory does not exist: {path}"
ERR_KEY_NOT_FOUND        = "Shape key '{name}' not found."
ERR_FILE_WRITE           = "File write error: {error}"
ERR_SELECT_MESH          = "Select a mesh object."
ERR_SELECT_SHAPE_KEY     = "Select a shape key first."

OK_EXPORT                = "OK — {count} deltas written to:\n{path}"

# ── Analyze operator messages ──────────────────────────────────────────────────

OK_ANALYZE               = "{count} boundary vertices found. Vertex group '{group}' updated."
OK_NO_BOUNDARIES         = "No boundary vertices found — shape key transitions look smooth."

# ── Smooth operator messages ───────────────────────────────────────────────────

WARN_NOTHING_TO_SMOOTH   = "No boundary vertices found — nothing to smooth."
OK_SMOOTH                = (
    "{passes} pass(es) applied. "
    "{seeds} boundary seed(s) expanded to {total} vertices."
)
