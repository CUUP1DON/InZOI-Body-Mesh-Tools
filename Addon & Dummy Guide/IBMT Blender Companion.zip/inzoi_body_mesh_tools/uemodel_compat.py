# uemodel_compat.py — UEFormat (.uemodel) coordinate-space correction
#
# WHY THIS EXISTS
# ───────────────
# The UEFormat Blender importer (io_scene_ueformat) bakes a (1, -1, 1) axis
# flip directly into every vertex position and normal when it stores them in
# the Blender mesh.  This is intentional — it converts the mesh from UE's
# left-handed (X-forward, Y-right, Z-up) coordinate space to Blender's
# right-handed world space.
#
# The PSK importer (io_scene_psk_psa) does NOT apply this flip; it stores
# raw UE-space positions and lets object-level scale/rotation do the work.
#
# The C++ BlenderToUE converter in the UE plugin expects PSK-style raw UE
# position data.  It performs:
#
#   BlenderToUE(B) = (B.X, -B.Y, B.Z)
#
# For PSK:    vertex Y = raw UE Y  →  -raw_UE_Y after C++ flip  →  correct ✓
# For UEModel: vertex Y = -raw UE Y  →  +raw_UE_Y after C++ flip  →  WRONG ✗
#
# Fix: negate the Y component of every exported basisPos, delta, basisNormal,
# and deformedNormal when the mesh originates from a UEFormat import.  This
# cancels the baked flip so that the C++ side receives the same data it would
# get from a PSK-sourced export.
# ─────────────────────────────────────────────────────────────────────────────

import mathutils


def correct_coords(bp_w: mathutils.Vector,
                   d_w:  mathutils.Vector,
                   bn_w: mathutils.Vector,
                   dn_w: mathutils.Vector):
    """
    Negate Y on all four per-vertex vectors to cancel the (1, -1, 1) flip
    that UEFormat bakes into vertex positions and normals.

    Parameters
    ----------
    bp_w : world-space basis position (already scaled to metres)
    d_w  : world-space position delta  (already scaled to metres)
    bn_w : world-space basis normal    (unit length)
    dn_w : world-space deformed normal (unit length)

    Returns
    -------
    Tuple (bp_c, d_c, bn_c, dn_c) — corrected versions of the inputs.
    """
    bp_c = mathutils.Vector(( bp_w.x, -bp_w.y,  bp_w.z))
    d_c  = mathutils.Vector(( d_w.x,  -d_w.y,   d_w.z))
    bn_c = mathutils.Vector((bn_w.x,  -bn_w.y,  bn_w.z))
    dn_c = mathutils.Vector((dn_w.x,  -dn_w.y,  dn_w.z))
    return bp_c, d_c, bn_c, dn_c
