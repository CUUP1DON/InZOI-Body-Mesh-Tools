bl_info = {
    "name":        "InZOI Body Mesh Tools Companion",
    "author":      "CUUPIDON",
    "version":     (0, 0, 4),
    "blender":     (4, 5, 0),
    "location":    "3D Viewport > Sidebar (N) > Body Mesh Tools",
    "description": "Export shape key deltas as JSON for the Body Mesh Tools UE plugin",
    "category":    "Mesh",
}

import bpy
import json
import math
import os
import mathutils
from bpy.props import StringProperty, PointerProperty, EnumProperty, IntProperty, BoolProperty
from bpy.types import PropertyGroup, Operator, Panel
from . import messages as M
from . import uemodel_compat

_EPSILON = 1e-6
_STATUS_CLEAR_DELAY = 6.0  # seconds before status messages auto-clear


def _schedule_clear():
    """Register a one-shot timer that clears the status field."""
    def _clear():
        props = bpy.context.scene.inzoi_morph_props
        props.status = ""
        return None  # returning None cancels the timer
    bpy.app.timers.register(_clear, first_interval=_STATUS_CLEAR_DELAY)


def _build_adjacency(mesh):
    """Return {vertex_index: [neighbour_indices]} built from mesh edges."""
    adj = {i: [] for i in range(len(mesh.vertices))}
    for edge in mesh.edges:
        a, b = edge.vertices[0], edge.vertices[1]
        adj[a].append(b)
        adj[b].append(a)
    return adj


def _compute_gradient_weights(mesh, delta_mags, gradient_rings):
    """
    For each hot vertex (delta_mag > _EPSILON) compute a [0..1] smoothstep weight
    based on how many edge hops it is from the nearest cold (zero-delta) neighbour.

    Distance 0 (directly touches a cold vertex) → weight 0 (delta zeroed out).
    Distance >= gradient_rings                   → weight 1 (full delta, not in dict).
    Vertices not present in the returned dict are fully interior → use 1.0.
    """
    adj = _build_adjacency(mesh)

    # BFS seed: hot vertices that share an edge with a cold vertex (distance = 0)
    dist   = {}
    frontier = []
    for edge in mesh.edges:
        a, b  = edge.vertices[0], edge.vertices[1]
        a_hot = delta_mags[a] > _EPSILON
        b_hot = delta_mags[b] > _EPSILON
        if a_hot and not b_hot and a not in dist:
            dist[a] = 0
            frontier.append(a)
        elif b_hot and not a_hot and b not in dist:
            dist[b] = 0
            frontier.append(b)

    # BFS inward through hot vertices up to (gradient_rings - 1) hops
    for hop in range(1, gradient_rings):
        next_frontier = []
        for vi in frontier:
            for nb in adj[vi]:
                if nb not in dist and delta_mags[nb] > _EPSILON:
                    dist[nb] = hop
                    next_frontier.append(nb)
        frontier = next_frontier
        if not frontier:
            break

    # Map hop distance to smoothstep weight; fully interior verts are NOT in the dict
    weights = {}
    for vi, d in dist.items():
        t = max(0.0, min(1.0, d / gradient_rings))   # 0 at boundary → 1 at interior
        weights[vi] = t * t * (3.0 - 2.0 * t)        # smoothstep
    return weights


def _shape_key_items(self, context):
    obj = self.source_object
    if obj and obj.type == 'MESH' and obj.data.shape_keys:
        ref = obj.data.shape_keys.reference_key
        items = [
            (kb.name, kb.name, "")
            for kb in obj.data.shape_keys.key_blocks
            if kb != ref
        ]
        if items:
            return items
    return [("__NONE__", "(no shape keys)", "")]


class InZOIMorphProps(PropertyGroup):
    source_object: PointerProperty(
        name=M.PROP_SOURCE_OBJECT_NAME,
        description=M.PROP_SOURCE_OBJECT_DESC,
        type=bpy.types.Object,
        poll=lambda self, o: o.type == 'MESH',
    )
    shape_key_name: EnumProperty(
        name=M.PROP_SHAPE_KEY_NAME,
        description=M.PROP_SHAPE_KEY_DESC,
        items=_shape_key_items,
    )
    morph_ue_name: StringProperty(
        name=M.PROP_MORPH_UE_NAME,
        description=M.PROP_MORPH_UE_DESC,
        default="Body_Muscle",
    )
    output_path: StringProperty(
        name=M.PROP_OUTPUT_PATH_NAME,
        description=M.PROP_OUTPUT_PATH_DESC,
        default="//",
        subtype='DIR_PATH',
    )
    status: StringProperty(default="")
    mesh_source: EnumProperty(
        name=M.PROP_MESH_SOURCE_NAME,
        description=M.PROP_MESH_SOURCE_DESC,
        items=[
            ('PSK',     '.psk',        'Imported with io_scene_psk_psa. Raw UE-space vertices, no Y-axis flip.'),
            ('UEMODEL', '.uemodel', 'Imported with io_scene_ueformat. Y-axis flip is baked into vertex data.'),
            ('FBX',     '.fbx',         'Imported via FBX or another format. Blender applies its own axis correction on import, so no extra Y-flip fix is needed — same behaviour as PSK.'),
        ],
        default='PSK',
    )
    use_auto_gradient: BoolProperty(
        name=M.PROP_USE_AUTO_GRADIENT_NAME,
        description=M.PROP_USE_AUTO_GRADIENT_DESC,
        default=True,
    )
    gradient_rings: IntProperty(
        name=M.PROP_GRADIENT_RINGS_NAME,
        description=M.PROP_GRADIENT_RINGS_DESC,
        default=8, min=2, max=32,
    )


class INZOI_OT_ExportMorphJson(Operator):
    bl_idname      = "inzoi.export_morph_json"
    bl_label       = M.OP_EXPORT_LABEL
    bl_description = "Export the selected shape key as an inZOI morph JSON file"
    bl_options     = {'REGISTER'}

    def execute(self, context):
        props   = context.scene.inzoi_morph_props
        props.status = ""
        obj     = props.source_object
        sk_name = props.shape_key_name
        out_dir = bpy.path.abspath(props.output_path)
        ue_name = props.morph_ue_name.strip() or sk_name
        safe_name = "".join(c if c.isalnum() or c in "_-" else "_" for c in ue_name)
        output  = os.path.join(out_dir, safe_name + ".json")

        if not obj:
            return self._fail(props, M.ERR_NO_OBJECT)
        if obj.type != 'MESH':
            return self._fail(props, M.ERR_NOT_MESH)
        if not obj.data.shape_keys:
            return self._fail(props, M.ERR_NO_SHAPE_KEYS)
        if sk_name in ("__NONE__", ""):
            return self._fail(props, M.ERR_NO_KEY_SELECTED)
        if not out_dir:
            return self._fail(props, M.ERR_NO_OUTPUT_DIR)
        if not os.path.isdir(out_dir):
            return self._fail(props, M.ERR_OUTPUT_NOT_EXIST.format(path=out_dir))

        mesh       = obj.data
        basis_key  = mesh.shape_keys.reference_key
        target_key = mesh.shape_keys.key_blocks.get(sk_name)
        if not target_key:
            return self._fail(props, M.ERR_KEY_NOT_FOUND.format(name=sk_name))

        # ── Ensure Object Mode and morph at 1.0 before export ────────────────
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        context.view_layer.objects.active = obj
        obj.select_set(True)
        target_key.value = 1.0
        context.view_layer.update()

        saved         = {kb.name: kb.value for kb in mesh.shape_keys.key_blocks}
        saved[sk_name] = 0.0  # restore morph to 0 (rest shape) after export
        world_mat     = obj.matrix_world
        world_mat_3x3 = world_mat.to_3x3()
        normal_mat    = world_mat_3x3.inverted().transposed()

        # Auto-detect unit scale: FModel exports at scale 1.0 store raw UE cm as
        # Blender units, making a body ~175 units tall. A correctly-scaled import
        # (scale 0.01) produces ~1.75 units. Threshold of 10 safely separates them.
        bbox_corners = [world_mat @ mathutils.Vector(c) for c in obj.bound_box]
        bbox_height  = max(c.z for c in bbox_corners) - min(c.z for c in bbox_corners)
        unit_scale   = 0.01 if bbox_height > 10.0 else 1.0

        try:
            for kb in mesh.shape_keys.key_blocks:
                kb.value = 0.0
            context.view_layer.update()
            dep     = context.evaluated_depsgraph_get()
            ev      = obj.evaluated_get(dep)
            em      = ev.to_mesh()
            bn_list = [v.normal.copy() for v in em.vertices]
            ev.to_mesh_clear()

            target_key.value = 1.0
            context.view_layer.update()
            dep     = context.evaluated_depsgraph_get()
            ev      = obj.evaluated_get(dep)
            em      = ev.to_mesh()
            dn_list = [v.normal.copy() for v in em.vertices]
            ev.to_mesh_clear()
        finally:
            for kb in mesh.shape_keys.key_blocks:
                if kb.name in saved:
                    kb.value = saved[kb.name]
            context.view_layer.update()
            for area in context.screen.areas:
                area.tag_redraw()

        basis_co  = basis_key.data
        target_co = target_key.data

        # Pre-compute local-space delta magnitudes (needed for gradient falloff)
        delta_mags = [0.0] * len(basis_co)
        for i in range(len(basis_co)):
            bp = basis_co[i].co
            tp = target_co[i].co
            dx = tp.x - bp.x
            dy = tp.y - bp.y
            dz = tp.z - bp.z
            delta_mags[i] = math.sqrt(dx*dx + dy*dy + dz*dz)

        # Auto Gradient Falloff: smoothly taper deltas to 0 at morph boundaries
        gradient_weights = None
        if props.use_auto_gradient and props.gradient_rings >= 2:
            gradient_weights = _compute_gradient_weights(mesh, delta_mags, props.gradient_rings)

        verts_out = []

        for i in range(len(basis_co)):
            if delta_mags[i] <= _EPSILON:
                continue

            # Gradient weight: 0 at hot/cold boundary, 1 deep in the morphed interior
            w = gradient_weights.get(i, 1.0) if gradient_weights is not None else 1.0
            if w <= 0.0:
                continue

            bp = basis_co[i].co
            tp = target_co[i].co
            dx = (tp.x - bp.x) * w
            dy = (tp.y - bp.y) * w
            dz = (tp.z - bp.z) * w

            bp_w    = (world_mat @ bp) * unit_scale
            d_w     = (world_mat_3x3 @ mathutils.Vector((dx, dy, dz))) * unit_scale
            bn_w    = (normal_mat @ bn_list[i]).normalized()
            dn_raw  = (normal_mat @ dn_list[i]).normalized()
            # Blend deformed normal toward basis normal proportional to gradient weight
            # so normal transitions are as smooth as position transitions
            dn_w    = bn_w.lerp(dn_raw, w).normalized()

            if props.mesh_source == 'UEMODEL':
                bp_w, d_w, bn_w, dn_w = uemodel_compat.correct_coords(bp_w, d_w, bn_w, dn_w)

            verts_out.append({
                "blenderIdx":     i,
                "basisPos":       [bp_w.x,  bp_w.y,  bp_w.z],
                "delta":          [d_w.x,   d_w.y,   d_w.z],
                "basisNormal":    [bn_w.x,  bn_w.y,  bn_w.z],
                "deformedNormal": [dn_w.x,  dn_w.y,  dn_w.z],
            })

        data = {
            "morphName":          ue_name,
            "blenderObject":      obj.name,
            "meshSource":         props.mesh_source,
            "basisVertexCount":   len(basis_co),
            "exportedDeltaCount": len(verts_out),
            "unitScale":          unit_scale,
            "vertices":           verts_out,
        }

        try:
            with open(output, "w", encoding="utf-8") as f:
                json.dump(data, f, separators=(",", ":"))
        except OSError as e:
            return self._fail(props, M.ERR_FILE_WRITE.format(error=e))

        msg = M.OK_EXPORT.format(count=len(verts_out), path=output)
        props.status = msg
        self.report({'INFO'}, msg.replace("\n", " "))
        _schedule_clear()
        return {'FINISHED'}

    def _fail(self, props, msg):
        props.status = "ERROR: " + msg
        self.report({'ERROR'}, msg)
        _schedule_clear()
        return {'CANCELLED'}


class INZOI_PT_MorphPanel(Panel):
    bl_label       = "Body Muscle Delta Exporter"
    bl_idname      = "INZOI_PT_MorphPanel"
    bl_space_type  = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category    = "Body Mesh Tools"

    def draw(self, context):
        layout = self.layout
        props  = context.scene.inzoi_morph_props

        layout.prop(props, "mesh_source")

        layout.separator(factor=0.5)

        col = layout.column(align=True)
        col.prop(props, "source_object")
        col.prop(props, "shape_key_name")

        layout.separator()

        # ── Gradient Falloff ───────────────────────────────────────────────
        box = layout.box()
        box.label(text="Gradient Falloff", icon='MOD_SMOOTH')
        box.prop(props, "use_auto_gradient")
        if props.use_auto_gradient:
            box.prop(props, "gradient_rings")

        layout.separator(factor=0.5)

        # ── Exporter ───────────────────────────────────────────────────────
        layout.prop(props, "morph_ue_name")
        layout.prop(props, "output_path")

        layout.separator()
        layout.operator("inzoi.export_morph_json", icon='EXPORT')

        if props.status:
            box2 = layout.box()
            col2 = box2.column(align=True)
            col2.alert = props.status.startswith("ERROR")
            for line in props.status.split("\n"):
                col2.label(text=line)


_classes = (
    InZOIMorphProps,
    INZOI_OT_ExportMorphJson,
    INZOI_PT_MorphPanel,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.inzoi_morph_props = PointerProperty(type=InZOIMorphProps)


def unregister():
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.inzoi_morph_props


if __name__ == "__main__":
    register()